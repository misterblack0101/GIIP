/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giip;

import javax.swing.JOptionPane;

/**
 *
 * @author misterblack
 */
public class gamePage extends javax.swing.JFrame {

    int counter=0;  
    qna q= new qna(); //class object for common use
    attempt_info ai= new attempt_info();
    String user;
    
    
    public void setQues(qna q)  //function for setting questions on screen
    {

    btngrp.clearSelection();
    qArea.setText(q.question);
    opt1.setText(q.opt1);
    opt2.setText(q.opt2);
    opt3.setText(q.opt3);
    System.out.println("inside setQues function");    
   }    
    
    public void prep(int qnumber,int lvl)  // function for getting data from qna class, and callin setQues function
    {
        System.out.println("inside preparatory function");
        q.getQues(qnumber,lvl);
        ai.setQno(user, lvl, q.qno);
        q.qno++;
        System.out.println("The counter in prep function of gamePage class is=  "+counter);
        setQues(q);
       
    }
    
    public void questOver()
    {
        Easy e=new Easy(user);
        e.setVisible(true);
        setVisible(false);
    }
    
    
    public void checkAns(String s){
    
        if(s.equals(q.answer)){
        JOptionPane.showMessageDialog(this, "Correct Answer!!!");
         q.score+=10;
         ai.setScore(user, q.qlvl, q.score);
         scoreLabel.setText(String.valueOf(q.score));
         if(q.qno<=counter )
                prep(q.qno,q.qlvl);
         else
             questOver();
             
             
            
        }
        else
         {
         JOptionPane.showMessageDialog(this, "Wrong Answer!!!");
         q.score-=5;
         ai.setScore(user, q.qlvl, q.score);
         scoreLabel.setText(String.valueOf(q.score));

         if(q.qno<=counter )
                prep(q.qno,q.qlvl);
         else
             questOver();
        
         }
    }
    /**
     * Creates new form gamePage
     */
    public gamePage(String username, int i) {
        initComponents();
        setSize(978, 754);
        setResizable(false);   // doesn't allow window to be resized
        ruleBox.setEditable(false); // Doesn't allow rule textfield are to be edited by the player
        qArea.setEditable(false);
        
        user=username;
        q.qno = ai.getQno(user, i); //intializes question number from attempt_info class
        
        counter=q.getTotal(i);      //assigning the counter value by getting the total no. of questions for that particular value
        
         q.qlvl=i;                  //assigning level
         System.out.println("Insiide gamepage constructor, level value i="+i);
         q.score=ai.getScore(user, q.qlvl);     //getting old score
         scoreLabel.setText(String.valueOf(q.score));       //displaying old score
         prep(q.qno,q.qlvl);  //calls the prep functions
        
    }


   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btngrp = new javax.swing.ButtonGroup();
        panel1 = new javax.swing.JPanel();
        ansPanel = new javax.swing.JPanel();
        opt1 = new javax.swing.JRadioButton();
        opt2 = new javax.swing.JRadioButton();
        opt3 = new javax.swing.JRadioButton();
        scoreLabel = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ruleBox = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        qArea = new javax.swing.JTextArea();
        logoutbutton = new javax.swing.JButton();
        backbutton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setSize(new java.awt.Dimension(978, 754));
        getContentPane().setLayout(null);

        panel1.setBackground(new java.awt.Color(204, 204, 204));
        panel1.setPreferredSize(new java.awt.Dimension(978, 754));
        panel1.setLayout(null);

        ansPanel.setForeground(getBackground());
        ansPanel.setLayout(null);

        opt1.setBackground(getBackground());
        btngrp.add(opt1);
        opt1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt1ActionPerformed(evt);
            }
        });
        ansPanel.add(opt1);
        opt1.setBounds(50, 26, 320, 25);

        opt2.setBackground(getBackground());
        btngrp.add(opt2);
        opt2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt2ActionPerformed(evt);
            }
        });
        ansPanel.add(opt2);
        opt2.setBounds(50, 102, 320, 25);

        opt3.setBackground(getBackground());
        btngrp.add(opt3);
        opt3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opt3ActionPerformed(evt);
            }
        });
        ansPanel.add(opt3);
        opt3.setBounds(50, 180, 320, 25);

        panel1.add(ansPanel);
        ansPanel.setBounds(550, 70, 382, 264);

        scoreLabel.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
        scoreLabel.setText("00");
        panel1.add(scoreLabel);
        scoreLabel.setBounds(790, 360, 110, 80);

        jLabel2.setFont(new java.awt.Font("Tempus Sans ITC", 1, 36)); // NOI18N
        jLabel2.setText("SCORE");
        panel1.add(jLabel2);
        jLabel2.setBounds(600, 360, 150, 90);

        ruleBox.setColumns(20);
        ruleBox.setFont(new java.awt.Font("Arial Unicode MS", 2, 14)); // NOI18N
        ruleBox.setRows(5);
        ruleBox.setText("                          Rules:\n\n1. There are total 5 questions, and each question is compulsory.\n2. Each correct answer gives you 10 points.\n3. For every incorrect answer, 5 points will be deducted.\n");
        jScrollPane1.setViewportView(ruleBox);

        panel1.add(jScrollPane1);
        jScrollPane1.setBounds(200, 470, 556, 155);

        qArea.setBackground(getBackground());
        qArea.setColumns(20);
        qArea.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        qArea.setRows(5);
        qArea.setText("idhar \nquestions\naayenge\n");
        qArea.setAutoscrolls(false);
        jScrollPane2.setViewportView(qArea);

        panel1.add(jScrollPane2);
        jScrollPane2.setBounds(27, 36, 493, 370);

        logoutbutton.setBackground(new java.awt.Color(255, 0, 0));
        logoutbutton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        logoutbutton.setText("Log Out");
        logoutbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbuttonActionPerformed(evt);
            }
        });
        panel1.add(logoutbutton);
        logoutbutton.setBounds(800, 550, 129, 54);

        backbutton.setBackground(new java.awt.Color(102, 255, 0));
        backbutton.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        backbutton.setText("Back");
        backbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbuttonActionPerformed(evt);
            }
        });
        panel1.add(backbutton);
        backbutton.setBounds(10, 550, 141, 52);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/giip/bg white.PNG"))); // NOI18N
        jLabel1.setText("jLabel1");
        panel1.add(jLabel1);
        jLabel1.setBounds(0, -150, 980, 930);

        getContentPane().add(panel1);
        panel1.setBounds(0, 0, 970, 750);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void opt1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt1ActionPerformed
     if(opt1.isSelected()){
     
         checkAns(opt1.getText());
     }

    }//GEN-LAST:event_opt1ActionPerformed

    private void opt2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt2ActionPerformed
        if(opt2.isSelected()){
     
         checkAns(opt2.getText());
     }
    }//GEN-LAST:event_opt2ActionPerformed

    private void opt3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opt3ActionPerformed
       if(opt3.isSelected()){
     
         checkAns(opt3.getText());
     }
    }//GEN-LAST:event_opt3ActionPerformed

    private void logoutbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbuttonActionPerformed
        // TODO add your handling code here:
        startPage s1= new startPage();
        s1.setVisible(true);
        setVisible(false);
    }//GEN-LAST:event_logoutbuttonActionPerformed

    private void backbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbuttonActionPerformed
        // TODO add your handling code here:
        Easy e=new Easy(user);
        setVisible(false);
        e.setVisible(true);
        
    }//GEN-LAST:event_backbuttonActionPerformed

  
    public static void main(String args[]) {
        
      
               
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ansPanel;
    private javax.swing.JButton backbutton;
    private javax.swing.ButtonGroup btngrp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton logoutbutton;
    private javax.swing.JRadioButton opt1;
    private javax.swing.JRadioButton opt2;
    private javax.swing.JRadioButton opt3;
    private javax.swing.JPanel panel1;
    private javax.swing.JTextArea qArea;
    private javax.swing.JTextArea ruleBox;
    private javax.swing.JLabel scoreLabel;
    // End of variables declaration//GEN-END:variables
}
