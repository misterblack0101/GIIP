/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giip;

import java.sql.*;

/**
 *
 * @author misterblack
 */
public class qna {
    
    public String question, opt1, opt2, opt3, answer;
    public static int score;
    int qno,qlvl,qtotal;
    
    public void getQues(int qnumber, int lvl)
    {   
    try{
        System.out.println("Inside getQues function inside qna class");
        qno= qnumber;
        qlvl=lvl;
        String query="select * from questans where q_id="+qno+" and l_id="+qlvl;
        
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        
        System.out.println("Connected");
        System.out.println("query is =   "+query);
        
        Statement ps=con.createStatement();
        ResultSet rs= ps.executeQuery(query);
        System.out.println("connected to server");
            
        rs.next();
            
        question=rs.getString(3);
        opt1 = rs.getString(4);
        opt2=rs.getString(5);
        opt3 =rs.getString(6);
        answer=rs.getString(7);
           
        System.out.println(question);
        System.out.println(answer);
        System.out.println(opt3);
        System.out.println(opt2);
        System.out.println(opt1);
         
        
        
        
    }
    catch(Exception e){
                        System.out.println(e);
                      }
    
}

public int getTotal(int lvl)        //returns the total number of questions in the level
{
try {
    
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");  
        Statement ps=con.createStatement();
        ResultSet rs=ps.executeQuery("select count(q_id) from questans where l_id="+lvl);
        rs.next();
        qtotal=rs.getInt(1);
        System.out.println("Returning value of total questions for level= "+qtotal);
        return qtotal;
    }
catch(Exception e){System.out.println(e);}

return qtotal;
}  
    
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        

        
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



}
    

    
  
