/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package giip;

import java.sql.*;

/**
 *
 * @author misterblack
 */
public class attempt_info    //this class will be used to acces the attempt info table in database
{
    
 String user;
 
 public void setUsername(String username)
 {
  user=username;
 }        
 
 public String getUsername()
 {
 return user;
 }     
    
    
public boolean setValue(String user)      //used to set various default parameters for the table upon getting the user_id
{
    try
    {
        System.out.println("Inside setValue function of attempt_info class");
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        Statement ps=con.createStatement();
        
        
            for(int i=1; i<6;++i)
            {
               System.out.println("INSERT INTO `attempt_info`(`user_id`, `lvl_id`, `score`, `qno`) VALUES (\""+user+"\","+i+",0,1)");
               ps.executeUpdate("INSERT INTO `attempt_info`(`user_id`, `lvl_id`, `score`, `qno`) VALUES (\""+user+"\","+i+",0,1)");
            }
        
        System.out.println("Default values set in attempt info");
        return true;
    }
    catch(Exception e)
    {
        System.out.println(e);
    }
    

return false;

}
    
    
public int getQno(String User, int lvl)
{
    try
    {
        System.out.println("Inside getQno function of attempt_info class");
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        Statement ps=con.createStatement();
        ResultSet rs= ps.executeQuery("SELECT qno FROM attempt_info WHERE user_id=\""+User+"\" and lvl_id="+lvl);
        rs.next();
        
        return rs.getInt(1);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }   
return 0;
}


public void setQno(String User, int lvl, int qno)
{
    try
    {
        System.out.println("Inside setQno function of attempt_info class");
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        Statement ps=con.createStatement();
        ps.executeUpdate("UPDATE attempt_info set qno="+qno+" where user_id=\""+User+"\" and lvl_id="+lvl);
        System.out.println("The new value of qno is set as   "+qno);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }   

}


public void setScore(String User, int lvl, int score)
{
    try
    {
        System.out.println("Inside setQno function of attempt_info class");
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        Statement ps=con.createStatement();
        ps.executeUpdate("UPDATE attempt_info set score="+score+" where user_id=\""+User+"\" and lvl_id="+lvl);
        System.out.println("The new value of score is set as   "+score);
    }
    catch(Exception e)
    {
        System.out.println(e);
    }   

}



public int getScore(String User, int lvl)
{
    try
    {
        System.out.println("Inside setQno function of attempt_info class");
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectx", "root", "");
        Statement ps=con.createStatement();
        ResultSet rs= ps.executeQuery("SELECT score FROM attempt_info WHERE user_id=\""+User+"\" and lvl_id="+lvl);
        rs.next();
        return rs.getInt(1); 
    }
    catch(Exception e)
    {
        System.out.println(e);
    }   
 
 return 0;   

}


}
